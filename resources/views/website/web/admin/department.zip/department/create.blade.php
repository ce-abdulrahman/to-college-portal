@extends('website.web.admin.layouts.app')

@section('page_name', 'department')
@section('view_name', 'create')

@section('content')
    
    {{-- Actions bar --}}
    <div class="row mb-4">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">داشبۆرد</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.departments.index') }}">بەشەکان</a></li>
                        <li class="breadcrumb-item active">زیادکردنی بەش</li>
                    </ol>
                </div>
                <h4 class="page-title">
                    <i class="fas fa-building-columns me-1"></i>
                    زیادکردنی بەش
                </h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-xl-10 mx-auto">
            <div class="card glass fade-in">
                <div class="card-body">
                    <h4 class="card-title mb-4"><i class="fa-solid fa-plus me-2"></i> زیادکردنی بەش</h4>

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> هەڵە هەیە لە داهێنان:
                            <ul class="mb-0 mt-2 ps-3">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('admin.departments.store') }}" method="POST" class="needs-validation"
                          enctype="multipart/form-data" novalidate>
                        @csrf

                        <div class="row g-3">
                            {{-- System --}}
                            <div class="col-12 col-md-6">
                                <label for="system_id" class="form-label">سیستەم</label>
                                <select id="system_id" name="system_id"
                                        class="form-select @error('system_id') is-invalid @enderror" required>
                                    <option value="" disabled selected>هەڵبژاردنی سیستەم</option>
                                    @foreach ($systems as $system)
                                        <option value="{{ $system->id }}" @selected(old('system_id') == $system->id)>
                                            {{ $system->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('system_id') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            {{-- Province --}}
                            <div class="col-12 col-md-6">
                                <label for="province_id" class="form-label">پارێزگا</label>
                                <select id="province_id" name="province_id"
                                        class="form-select @error('province_id') is-invalid @enderror" required>
                                    <option value="" disabled selected>هەڵبژاردنی پارێزگا</option>
                                    @foreach ($provinces as $province)
                                        <option value="{{ $province->id }}" @selected(old('province_id') == $province->id)>
                                            {{ $province->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('province_id') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            {{-- University (depends on province) --}}
                            <div class="col-12 col-md-6">
                                <label for="university_id" class="form-label">زانکۆ</label>
                                <select id="university_id" name="university_id"
                                        class="form-select @error('university_id') is-invalid @enderror" required disabled>
                                    <option value="">هەموو زانکۆكان</option>
                                </select>
                                @error('university_id') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            {{-- College (depends on university) --}}
                            <div class="col-12 col-md-6">
                                <label for="college_id" class="form-label">کۆلێژ/پەیمانگا</label>
                                <select id="college_id" name="college_id"
                                        class="form-select @error('college_id') is-invalid @enderror" required disabled>
                                    <option value="">هەموو کۆلێژەکان</option>
                                </select>
                                @error('college_id') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            {{-- Names --}}
                            <div class="col-12 col-md-6">
                                <label for="name" class="form-label">ناوی بەش</label>
                                <input id="name" name="name" type="text"
                                       class="form-control @error('name') is-invalid @enderror"
                                       value="{{ old('name') }}" required>
                                @error('name') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            <div class="col-12 col-md-6">
                                <label for="name_en" class="form-label">ناوی بەش (ئینگلیزی)</label>
                                <input id="name_en" name="name_en" type="text"
                                       class="form-control @error('name_en') is-invalid @enderror"
                                       value="{{ old('name_en') }}" required>
                                @error('name_en') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                            </div>

                            {{-- Scores --}}
                            <div class="col-12 col-md-3">
                                <label for="local_score" class="form-label">ن. ناوەندی</label>
                                <input id="local_score" name="local_score" type="number" step="0.001"
                                       class="form-control" value="{{ old('local_score') }}">
                            </div>

                            <div class="col-12 col-md-3">
                                <label for="external_score" class="form-label">ن. دەرەوە</label>
                                <input id="external_score" name="external_score" type="number" step="0.001"
                                       class="form-control" value="{{ old('external_score') }}">
                            </div>

                            {{-- Type / Sex --}}
                            <div class="col-12 col-md-3">
                                <label for="type" class="form-label">لق</label>
                                <select id="type" name="type" class="form-select">
                                    <option value="زانستی" @selected(old('type') === 'زانستی')>زانستی</option>
                                    <option value="وێژەیی" @selected(old('type') === 'وێژەیی')>وێژەیی</option>
                                    <option value="زانستی و وێژەیی" @selected(old('type') === 'زانستی و وێژەیی')>هەردوو</option>
                                </select>
                            </div>

                            <div class="col-12 col-md-3">
                                <label for="sex" class="form-label">ڕەگەز</label>
                                <select id="sex" name="sex" class="form-select">
                                    <option value="نێر" @selected(old('sex') === 'نێر')>نێر</option>
                                    <option value="مێ" @selected(old('sex') === 'مێ')>مێ</option>
                                </select>
                            </div>

                            {{-- Leaflet map --}}
                            <div id="map" style="height:420px;border-radius:12px" class="m-3"></div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Latitude</label>
                                    <input id="lat" name="lat" type="number" step="0.000001"
                                           value="{{ old('lat') }}" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Longitude</label>
                                    <input id="lng" name="lng" type="number" step="0.000001"
                                           value="{{ old('lng') }}" class="form-control">
                                </div>
                                <div class="form-text">لەسەر نەخشە کلیک بکە بۆ دیاریکردنی شوێن.</div>
                            </div>

                            {{-- Description --}}
                            <div class="col-12">
                                <label for="description" class="form-label">وەسف</label>
                                <textarea id="description" name="description" class="form-control summernote" rows="4">{{ old('description') }}</textarea>
                            </div>

                            {{-- Image --}}
                            <div class="col-12 col-md-6">
                                <label class="form-label">وێنە</label>
                                <input type="file" name="image" class="form-control" accept="image/*">
                            </div>

                            {{-- Status --}}
                            <div class="col-12 col-md-6">
                                <label for="status" class="form-label">دۆخ</label>
                                <select id="status" name="status" class="form-select" required>
                                    <option value="1" @selected(old('status') === '1')>چاڵاک</option>
                                    <option value="0" @selected(old('status') === '0')>ناچاڵاک</option>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa-solid fa-floppy-disk me-1"></i> پاشەکەوتکردن
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection


@push('scripts')

    {{-- API base urls (hardcode مەکەین) --}}
    <script>
        window.PAGE = "@yield('page_name')";
        window.VIEW = "@yield('view_name')";
        window.API_UNI   = "{{ route('admin.api.universities') }}"; // ?province_id=ID
        window.API_COLLS = "{{ route('admin.api.colleges') }}";     // ?university_id=ID
    </script>

@endpush
