$(document).ready(function() {
    var table;

    // Initialize DataTable or get existing instance
    if ($.fn.dataTable.isDataTable('#collegesTable')) {
        table = $('#collegesTable').DataTable();
    } else {
        table = $('#collegesTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/ku.json'
            },
            pageLength: 10,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: '<"top"f>rt<"bottom"ilp><"clear">',
            columnDefs: [
                { orderable: false, targets: [6] } // Actions column
            ],
            initComplete: function() {
                updateTableInfo();
                // Initialize tooltips
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            },
            drawCallback: function() {
                updateTableInfo();
            }
        });
    }

    // Set up event handlers (these are set only once per page load)
    function setupEventHandlers() {
        // Page length change
        $('#page-length').on('change', function() {
            table.page.len($(this).val()).draw();
        });

        // Custom search
        $('#custom-search').on('keyup', function() {
            table.search(this.value).draw();
        });

        // Status filter
        $('#filter-status').on('change', function() {
            var status = $(this).val();
            if (status === '') {
                table.column(5).search('').draw();
            } else {
                table.column(5).search('^' + status + '$', true, false).draw();
            }
        });

        // Province filter
        $('#filter-province').on('change', function() {
            var provinceId = $(this).val();
            if (provinceId === '') {
                $('#filter-university').val('').prop('disabled', true);
                table.column(2).search('').draw();
                table.column(3).search('').draw();
            } else {
                fetchUniversities(provinceId);
                table.column(2).search(provinceId).draw();
            }
        });

        // University filter
        $('#filter-university').on('change', function() {
            var universityId = $(this).val();
            if (universityId === '') {
                table.column(3).search('').draw();
            } else {
                table.column(3).search(universityId).draw();
            }
        });

        // Reset filters
        $('#filter-reset').on('click', function() {
            $('#filter-province').val('');
            $('#filter-university').val('').prop('disabled', true);
            $('#filter-status').val('');
            $('#custom-search').val('');
            $('#page-length').val('10');
            
            table.columns().search('').draw();
            table.search('').draw();
            table.page.len(10).draw();
        });

        // Delete confirmation (event delegation)
        $(document).on('submit', 'form[onsubmit*="confirm"]', function(e) {
            e.preventDefault();
            var form = this;
            var confirmMessage = $(form).attr('onsubmit').match(/confirm\('([^']+)'\)/)[1] || 'دڵنیایت؟';
            
            Swal.fire({
                title: confirmMessage,
                text: 'ئەم کردارە گەڕانەوەی نیە!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'بەڵێ، بسڕەوە!',
                cancelButtonText: 'نەخێر',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });

        // Window resize
        $(window).on('resize', function() {
            setTimeout(function() {
                table.columns.adjust();
            }, 100);
        });
    }

    // Call setupEventHandlers once
    setupEventHandlers();

    // Update table info
    function updateTableInfo() {
        var info = table.page.info();
        var start = info.start + 1;
        var end = info.end;
        var total = info.recordsTotal;
        var filtered = info.recordsDisplay;
        
        var infoText = filtered === total 
            ? `نیشاندان ${start} بۆ ${end} لە کۆی ${total}`
            : `نیشاندان ${start} بۆ ${end} لە کۆی ${filtered} (فیلتەرکراو لە ${total})`;
        
        $('#dt-info').html(`<i class="fa-solid fa-table me-1"></i> ${infoText}`);
    }

    // Fetch universities for a province
    function fetchUniversities(provinceId) {
        if (!provinceId) return;
        
        var universitySelect = $('#filter-university');
        universitySelect.prop('disabled', true).html('<option value="">چاوەروان بکە...</option>');
        
        $.ajax({
            url: window.UNI_API || '/api/universities/by-province/' + provinceId,
            method: 'GET',
            data: { province_id: provinceId },
            success: function(response) {
                var options = '<option value="">هەموو زانکۆكان</option>';
                if (response.data && response.data.length > 0) {
                    $.each(response.data, function(index, university) {
                        options += '<option value="' + university.id + '">' + university.name + '</option>';
                    });
                }
                universitySelect.html(options).prop('disabled', false);
            },
            error: function() {
                universitySelect.html('<option value="">هەڵە لە وەرگرتن</option>').prop('disabled', false);
                showToast('هەڵە', 'نەتوانرا زانکۆکان وەربگیرێت', 'error');
            }
        });
    }

    // Toast notification
    function showToast(title, message, type) {
        if (typeof Swal !== 'undefined') {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            });
            
            Toast.fire({
                icon: type,
                title: title,
                text: message
            });
        }
    }
});